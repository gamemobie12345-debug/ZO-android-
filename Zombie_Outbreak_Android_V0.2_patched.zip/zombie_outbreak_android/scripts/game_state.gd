extends Node
class_name GameState

signal state_changed
signal story_added(entry: String)
signal combat_changed
signal visitor_changed

const SAVE_PATH := "user://zombie_outbreak_save.json"
const SURVIVAL_INTERVAL_MIN := 60
const SURVIVAL_COST := 5
const HP_STARVATION_COST := 5
const TURNS_PER_TIME_TICK := 3
const MINUTES_PER_TIME_TICK := 2

const FLOOR_DATA := {
	"Tầng hầm": {"title":"TẦNG HẦM", "description":"Bãi xe tối om, phòng máy phát và kho bảo trì. Có thể tìm dụng cụ, nhưng tiếng động vang rất xa.", "loot":["Ống tuýp", "Nước", "Băng gạc", "Súng phóng lựu"]},
	"Tầng trệt": {"title":"TẦNG TRỆT", "description":"Sảnh chung cư, quầy bảo vệ và cửa kính hướng ra con phố hỗn loạn.", "loot":["Dao gấp", "Nước", "Đèn pin"]},
	"Tầng 2": {"title":"TẦNG 2", "description":"Các căn hộ gia đình. Một vài cửa mở hé, tiếng tivi vẫn phát từ căn phòng cuối hành lang.", "loot":["Thức ăn", "Băng gạc", "Gậy bóng chày"]},
	"Tầng 3": {"title":"TẦNG 3 · NHÀ HÀNG", "description":"Nhà hàng của chung cư. Kho bếp có thực phẩm đóng gói và nước uống; khu ăn uống có nhiều vật cản.", "loot":["Thức ăn", "Nước", "Mã tấu"]},
	"Tầng 4": {"title":"TẦNG 4", "description":"Khu căn hộ dịch vụ. Hành lang yên tĩnh bất thường; một căn hộ có dấu hiệu bị cạy khóa.", "loot":["Băng gạc", "Thức ăn", "Đạn súng lục"]},
	"Tầng 5": {"title":"TẦNG 5 · KHU VỰC MẮC KẸT", "description":"Cửa chống cháy bị chặn. Có tiếng người kêu cứu phía sau, nhưng cũng có tiếng cào cấu sát bên kia cửa.", "loot":["Nước", "Băng gạc", "Đạn shotgun"]},
	"Tầng 6": {"title":"TẦNG 6", "description":"Khu căn hộ đang sửa chữa. Giàn giáo, dây điện và vật liệu xây dựng có thể tạo lối đi hoặc cái bẫy.", "loot":["Ống tuýp", "Đèn pin", "Đạn súng tỉa"]},
	"Tầng 7": {"title":"TẦNG 7", "description":"Một tầng căn hộ yên ắng bất thường. Cửa sổ nhìn ra thành phố; có dấu vết một nhóm người từng cố thủ tại đây.", "loot":["Súng lục", "Thức ăn", "Đạn súng lục"]},
	"Tầng 8": {"title":"TẦNG 8", "description":"Tầng căn hộ áp mái, hành lang hẹp và nhiều cửa khóa. Một lối kỹ thuật dẫn lên sân thượng có thể vẫn sử dụng được.", "loot":["Nước", "Đèn pin", "Băng gạc"]},
	"Sân thượng": {"title":"SÂN THƯỢNG", "description":"Bồn nước, ăng-ten và lối tiếp cận mái nhà bên cạnh. Đây có thể là đường thoát hoặc điểm bị dồn vào chân tường.", "loot":["Nước", "Băng gạc", "Súng tỉa"]}
}

const WEAPON_DATA := {
	"Tay không": {"damage":5, "noise":0, "kind":"melee", "ammo":-1, "description":"Không gây tiếng động, sát thương thấp nhất."},
	"Dao gấp": {"damage":12, "noise":0, "kind":"melee", "ammo":-1, "description":"Gọn nhẹ, sát thương cận chiến."},
	"Gậy bóng chày": {"damage":18, "noise":4, "kind":"melee", "ammo":-1, "description":"Tầm đánh tốt, có tiếng va đập."},
	"Ống tuýp": {"damage":20, "noise":5, "kind":"melee", "ammo":-1, "description":"Nặng và chắc, gây tiếng kim loại."},
	"Mã tấu": {"damage":28, "noise":2, "kind":"melee", "ammo":-1, "description":"Sát thương cận chiến cao."},
	"Súng lục": {"damage":35, "noise":75, "kind":"firearm", "ammo":6, "description":"Sát thương cao, tiếng súng dễ kéo zombie."},
	"Shotgun": {"damage":55, "noise":100, "kind":"firearm", "ammo":2, "description":"Sát thương rất cao ở cự ly gần, cực kỳ ồn."},
	"Súng tỉa": {"damage":90, "noise":85, "kind":"firearm", "ammo":1, "description":"Sát thương gần cao nhất, tiếng nổ vang xa."},
	"Súng phóng lựu": {"damage":100, "noise":100, "kind":"firearm", "ammo":1, "description":"Sát thương cao nhất, tiếng nổ cực lớn."}
}

var player_name := "Anker"
var started := false
var day := 1
var hour := 7
var minute := 42
var health := 100
var stamina := 100
var hunger := 80
var thirst := 80
var level := 1
var experience := 0
var game_over := false
var special_ending_unlocked := false
var special_ending_seen := false
var current_location := "Tầng trệt"
var inventory: Array[Dictionary] = []
var journal: Array[String] = []
var story: Array[String] = []
var minutes_since_survival_tick := 0
var dialogue_turns := 0
var rng := RandomNumberGenerator.new()
var npcs: Array[Dictionary] = []
var side_npcs: Array[Dictionary] = []
var discovered_floors: Array[String] = ["Tầng trệt"]
var searched_floors: Array[String] = []
var noise_investigated := false
var noise_warning_ignored := false
var bad_end_route := false
var combat_active := false
var zombie_name := ""
var zombie_health := 0
var zombie_max_health := 0
var zombie_damage := 0
var zombie_noise_level := 0
var zombie_turn := 0
var pending_visitor: Dictionary = {}
var rescued_visitor_count := 0
var negative_relationship_events := 0
var group_bond_scene_seen := false

func _ready() -> void:
	rng.randomize()
	_reset_npcs()

func _reset_npcs() -> void:
	npcs = [
		{"name":"Mai Anh", "age":24, "job":"Sinh viên y khoa", "specialty":"Sơ cứu", "affinity":0, "level":1, "memory":[], "personality":"điềm tĩnh, trách nhiệm, ưu tiên cứu người", "status":"Đang mắc kẹt ở một khu căn hộ", "met":false, "bond":"Mai Anh và Thảo Vy từng giúp nhau trong một lần sơ tán; cô thường tin vào sự quyết đoán của Vy."},
		{"name":"Thảo Vy", "age":22, "job":"Nhân viên văn phòng", "specialty":"Thể lực", "affinity":0, "level":1, "memory":[], "personality":"thẳng thắn, năng động, đôi khi bốc đồng", "status":"Đang tìm đường xuống tầng trệt", "met":false, "bond":"Thảo Vy xem Mai Anh như người bạn cần bảo vệ; cô thường bất đồng với sự thận trọng của Ngọc Hân."},
		{"name":"Hạ Linh", "age":26, "job":"Nhân viên IT", "specialty":"Công nghệ", "affinity":0, "level":1, "memory":[], "personality":"ít nói, quan sát tốt, thực tế", "status":"Đang cố khôi phục hệ thống camera", "met":false, "bond":"Hạ Linh từng làm việc cùng Ngọc Hân trong ban quản lý cư dân; cả hai có thể phối hợp rất tốt."},
		{"name":"Ngọc Hân", "age":28, "job":"Cư dân", "specialty":"Phòng vệ", "affinity":0, "level":1, "memory":[], "personality":"cẩn trọng, mạnh mẽ, bảo vệ người thân", "status":"Đang cố thủ gần cầu thang thoát hiểm", "met":false, "bond":"Ngọc Hân không dễ tin người lạ, nhưng luôn đặt sự an toàn của Mai Anh và Hạ Linh lên trước."}
	]

func start_game(chosen_name: String) -> void:
	player_name = chosen_name.strip_edges()
	if player_name.is_empty():
		player_name = "Anker"
	started = true
	day = 1
	hour = 7
	minute = 42
	health = 100
	stamina = 100
	hunger = 80
	thirst = 80
	level = 1
	experience = 0
	game_over = false
	special_ending_unlocked = false
	special_ending_seen = false
	current_location = "Tầng trệt"
	inventory.clear()
	journal.clear()
	story.clear()
	side_npcs.clear()
	discovered_floors = ["Tầng trệt"]
	searched_floors.clear()
	minutes_since_survival_tick = 0
	dialogue_turns = 0
	noise_investigated = false
	noise_warning_ignored = false
	bad_end_route = false
	combat_active = false
	pending_visitor.clear()
	rescued_visitor_count = 0
	negative_relationship_events = 0
	group_bond_scene_seen = false
	_reset_npcs()
	_add_story("Ngày 1 · 07:42 — Chung cư tại Sài Gòn.\nMột buổi sáng tưởng như bình thường. Điện thoại liên tục rung lên bởi những thông báo khẩn cấp về các vụ tấn công chưa rõ nguyên nhân. Ngoài cửa kính, còi xe cứu thương vang lên dồn dập.")
	_add_story("Tầng 5 phát ra tiếng kêu cứu ngắt quãng. Một bản tin radio bị nhiễu nhắc đến những vụ tấn công kỳ lạ. Chưa ai biết thứ gì đang khiến người nhiễm bệnh trở nên hung hãn.")
	_add_story("Bốn cô gái đang ở những vị trí khác nhau trong chung cư. Họ có mối liên hệ riêng, nhưng chưa ai biết Anker có tồn tại hay không.")
	_add_story("<b>CẢNH BÁO SỚM:</b> Có nên dành thời gian tìm hiểu xem zombie có phản ứng với tiếng ồn hay không? Một quyết định bị bỏ qua có thể khiến cả nhóm phải trả giá.")
	state_changed.emit()

func _add_story(entry: String) -> void:
	story.push_front(entry)
	if story.size() > 100:
		story.pop_back()
	story_added.emit(entry)

func add_journal(entry: String) -> void:
	journal.push_front("Ngày %d · %02d:%02d — %s" % [day, hour, minute, entry])
	if journal.size() > 120:
		journal.pop_back()

func investigate_noise() -> void:
	if not started or noise_investigated:
		return
	noise_investigated = true
	noise_warning_ignored = false
	_add_story("Anker dành thời gian kiểm chứng âm thanh từ một vị trí kín đáo. Qua quan sát những con zombie bên dưới, có thể xác nhận chúng lập tức quay đầu và di chuyển về phía nguồn âm thanh lớn. <b>KẾT LUẬN ĐÃ GHI NHỚ:</b> tiếng súng có thể kéo cả đàn zombie đến.")
	add_journal("Đã xác nhận zombie nhạy cảm với âm thanh lớn. Tránh nổ súng nếu không có đường rút.")
	register_dialogue_turn()
	state_changed.emit()

func ignore_noise_warning() -> void:
	if not started or noise_investigated:
		return
	noise_warning_ignored = true
	bad_end_route = true
	_add_story("Anker quyết định không điều tra cảnh báo. Tiếng động bên ngoài bị xem như một phần hỗn loạn của thành phố. Một dấu hiệu quan trọng đã bị bỏ lỡ.")
	add_journal("Bỏ qua việc điều tra phản ứng của zombie với tiếng ồn.")
	register_dialogue_turn()
	state_changed.emit()

func register_dialogue_turn() -> void:
	if game_over or not started:
		return
	dialogue_turns += 1
	if dialogue_turns >= TURNS_PER_TIME_TICK:
		dialogue_turns = 0
		advance_time(MINUTES_PER_TIME_TICK)

func advance_time(minutes: int) -> void:
	if game_over or not started or minutes <= 0:
		return
	var total := hour * 60 + minute + minutes
	while total >= 1440:
		total -= 1440
		day += 1
	hour = int(total / 60)
	minute = total % 60
	minutes_since_survival_tick += minutes
	while minutes_since_survival_tick >= SURVIVAL_INTERVAL_MIN and not game_over:
		minutes_since_survival_tick -= SURVIVAL_INTERVAL_MIN
		hunger = maxi(0, hunger - SURVIVAL_COST)
		thirst = maxi(0, thirst - SURVIVAL_COST)
		if hunger <= 0:
			health = maxi(0, health - HP_STARVATION_COST)
			_add_story("Cơn đói bào mòn thể lực. Sức khỏe giảm %d điểm." % HP_STARVATION_COST)
		if thirst <= 0:
			health = maxi(0, health - HP_STARVATION_COST)
			_add_story("Cơ thể mất nước nghiêm trọng. Sức khỏe giảm %d điểm." % HP_STARVATION_COST)
		if health <= 0:
			game_over = true
			_add_story("<b>GAME OVER</b> — Sức khỏe của %s đã cạn kiệt." % player_name)
			break
		_npc_world_cycle()
		_maybe_side_visitor()
	if special_ending_unlocked and not special_ending_seen:
		_add_story("<b>MỞ KHÓA KẾT THÚC ĐẶC BIỆT:</b> Cả bốn người đã đạt mức thân thuộc tuyệt đối. Một tương lai nơi tất cả sống cùng nhau giờ đã có thể lựa chọn.")
		special_ending_seen = true
	state_changed.emit()

func _npc_world_cycle() -> void:
	for i in range(npcs.size()):
		var npc: Dictionary = npcs[i]
		if int(npc.affinity) < 0 and rng.randf() < 0.60:
			var event_text := _negative_relationship_event(npc)
			negative_relationship_events += 1
			_add_story(event_text)
			add_journal("Biến cố quan hệ: " + _strip_markup(event_text))
			if npc.memory is Array:
				npc.memory.append("Đã xảy ra một biến cố tiêu cực liên quan đến mối quan hệ trong chu kỳ thế giới.")
			break
	if rng.randf() < 0.12:
		var index := rng.randi_range(0, npcs.size() - 1)
		var autonomous_npc: Dictionary = npcs[index]
		var autonomous_event_text := _autonomous_npc_event(autonomous_npc)
		_add_story(autonomous_event_text)
		add_journal("Hoạt động độc lập: " + _strip_markup(autonomous_event_text))
		autonomous_npc.memory.append("Tự hành động trong Ngày %d, %02d:%02d." % [day, hour, minute])

func _autonomous_npc_event(npc: Dictionary) -> String:
	match String(npc.specialty):
		"Sơ cứu": return "%s tự tìm bông băng và thuốc sát trùng trong một căn hộ bỏ trống. Cô ghi nhớ vị trí một túi cứu thương." % npc.name
		"Thể lực": return "%s mạo hiểm dò cầu thang bộ, tìm ra một lối di chuyển ít bị chặn hơn." % npc.name
		"Công nghệ": return "%s khôi phục được một phần camera an ninh. Trên màn hình, cô thoáng thấy bóng người chạy qua tầng 5." % npc.name
		_: return "%s gia cố một cánh cửa và chia phần nước còn lại cho người bên cạnh." % npc.name

func _negative_relationship_event(npc: Dictionary) -> String:
	# Affinity below zero creates a chance of conflict, not an automatic betrayal.
	# The event is selected to fit the character's temperament and specialty.
	match String(npc.specialty):
		"Sơ cứu":
			match rng.randi_range(0, 2):
				0: return "%s giữ khoảng cách và từ chối chữa trị ngay, yêu cầu Anker chứng minh rằng cả nhóm có thể tin tưởng lẫn nhau." % npc.name
				1: return "%s phản đối gay gắt cách phân chia thuốc men, cho rằng quyết định vừa rồi đặt sai người vào ưu tiên." % npc.name
				_: return "%s tự đi kiểm tra một phòng bệnh khác mà không báo trước. Cô không muốn tiếp tục phối hợp khi mối quan hệ đang căng thẳng." % npc.name
		"Thể lực":
			match rng.randi_range(0, 2):
				0: return "%s mất kiên nhẫn, công khai bác bỏ kế hoạch của Anker và đòi tự quyết định đường đi." % npc.name
				1: return "%s bỏ khỏi vị trí tranh cãi để tự tìm lối khác. Hành động bốc đồng khiến đội hình mất liên lạc trong chốc lát." % npc.name
				_: return "%s cố chứng minh mình đúng bằng một hành động liều lĩnh, khiến cả nhóm phải đề phòng thêm." % npc.name
		"Công nghệ":
			match rng.randi_range(0, 2):
				0: return "%s tạm ngừng chia sẻ dữ liệu camera, nói rằng cô không muốn thông tin mình thu thập bị sử dụng tùy tiện." % npc.name
				1: return "%s giữ im lặng về một tín hiệu vừa phát hiện cho đến khi tự xác minh. Sự thiếu tin tưởng làm cả nhóm bỏ lỡ thời gian." % npc.name
				_: return "%s yêu cầu được tự kiểm soát thiết bị liên lạc và nảy sinh tranh cãi khi Anker không đồng ý." % npc.name
		_:
			match rng.randi_range(0, 2):
				0: return "%s kiên quyết đóng chặt cửa phòng thủ, không cho người khác đi qua dù kế hoạch chung cần lối đó." % npc.name
				1: return "%s tự ý chuyển vị trí canh gác để bảo vệ khu vực mình cho là quan trọng hơn, khiến cả nhóm bất đồng." % npc.name
				_: return "%s thẳng thừng chất vấn quyền quyết định của Anker. Cô vẫn ở lại, nhưng không còn muốn phối hợp như trước." % npc.name

func _maybe_side_visitor() -> void:
	if not pending_visitor.is_empty() or rng.randf() > 0.18:
		return
	var names := ["Ông Phúc", "Bảo", "Cô Thu", "Minh Khang", "Bé Na"]
	var name: String = names[rng.randi_range(0, names.size() - 1)]
	pending_visitor = {"name":name, "condition":"bị thương nhẹ" if rng.randf() < 0.5 else "hoảng loạn", "trust":rng.randi_range(20, 70), "is_thief":rng.randf() < 0.22}
	var visitor_line := "%s gõ cửa nơi trú ẩn. Người này có vẻ %s và xin được giúp đỡ." % [name, pending_visitor.condition]
	if pending_visitor.is_thief:
		visitor_line += " Ánh mắt họ liên tục liếc về phía túi vật tư."
	_add_story("<b>NGƯỜI LẠ XUẤT HIỆN:</b> " + visitor_line)
	visitor_changed.emit()

func resolve_visitor(choice: String) -> void:
	if pending_visitor.is_empty():
		return
	var visitor_name: String = pending_visitor.name
	match choice:
		"rescue":
			rescued_visitor_count += 1
			side_npcs.append({"name":visitor_name, "status":"Được cứu", "memory":["Anker đã cứu giúp trong ngày đầu thảm họa."]})
			inventory.append({"name":"Băng gạc", "quantity":1, "type":"supply"})
			_add_story("Anker giúp %s vào nơi an toàn. Người này trao lại một cuộn băng gạc để cảm ơn." % visitor_name)
		"ignore":
			if bool(pending_visitor.get("is_thief", false)):
				var stolen := _steal_random_supply()
				_add_story("Anker không mở cửa. %s lợi dụng lúc mọi người mất cảnh giác, lấy trộm %s rồi bỏ chạy." % [visitor_name, stolen])
			else:
				_add_story("Anker không mở cửa. %s rời đi sau một lúc chờ đợi. Không ai biết chuyện gì xảy ra với người này sau đó." % visitor_name)
	pending_visitor.clear()
	visitor_changed.emit()
	state_changed.emit()

func _steal_random_supply() -> String:
	for i in range(inventory.size()):
		if String(inventory[i].get("type", "supply")) != "weapon" and int(inventory[i].get("quantity", 0)) > 0:
			var item_name: String = inventory[i].name
			inventory[i].quantity -= 1
			if inventory[i].quantity <= 0:
				inventory.remove_at(i)
			return item_name
	return "không có vật tư nào"

func perform_action(raw_action: String) -> void:
	if not started or game_over or combat_active:
		return
	var action := raw_action.strip_edges()
	if action.is_empty():
		return
	_add_story("<b>%s:</b> %s" % [player_name, _escape_bbcode(action)])
	var lower := action.to_lower()
	var response := "Hành động được ghi nhận. Môi trường xung quanh chưa có phản ứng rõ ràng; cần quan sát thêm để xác định kết quả."
	var stamina_cost := 0
	if _has_any(lower, ["quan sát", "nhìn ra ngoài", "nghe ngóng", "kiểm tra cửa"]):
		response = "Bên ngoài có tiếng còi hú xa dần. Dưới đường xuất hiện những người chạy tán loạn; vài bóng người di chuyển giật cục giữa các xe bỏ lại."
		stamina_cost = 2
	elif _has_any(lower, ["nghỉ", "ngủ", "nằm xuống"]):
		stamina = mini(100, stamina + 20)
		response = "Khoảng thời gian nghỉ giúp thể lực hồi phục."
	elif _has_any(lower, ["ăn", "thức ăn", "đồ ăn"]):
		if _consume_item("Thức ăn"):
			hunger = mini(100, hunger + 25)
			response = "Anh sử dụng một phần thức ăn. Cơn đói dịu xuống."
		else: response = "Trong túi chưa có thức ăn."
	elif _has_any(lower, ["băng gạc", "sơ cứu bản thân", "băng bó"]):
		if _consume_item("Băng gạc"):
			health = mini(100, health + 20)
			response = "Anh dùng băng gạc xử lý vết thương. HP hồi phục 20 điểm."
		else: response = "Trong túi không có băng gạc."
	elif _has_any(lower, ["uống", "nước"]):
		if _consume_item("Nước"):
			thirst = mini(100, thirst + 30)
			response = "Anh uống một chai nước. Cơn khát dịu xuống."
		else: response = "Trong túi chưa có nước."
	elif _has_any(lower, ["tìm kiếm", "lục", "kiếm đồ", "loot"]):
		response = search_current_floor()
	elif _has_any(lower, ["đi ra", "rời căn hộ", "mở cửa"]):
		stamina_cost = 5
		response = "Tay nắm cửa lạnh ngắt. Từ hành lang vọng lại tiếng va đập nặng nề. Cánh cửa vẫn đóng; quyết định tiếp theo thuộc về anh."
	elif _has_any(lower, ["mai anh", "thảo vy", "hạ linh", "ngọc hân"]):
		var npc_index := _find_npc_in_text(lower)
		if npc_index >= 0:
			var npc: Dictionary = npcs[npc_index]
			if not bool(npc.get("met", false)):
				response = "%s vẫn chưa gặp Anker. Việc nhắc tên cô ấy không làm thay đổi mối quan hệ." % npc.name
			else:
				var positive := _has_any(lower, ["giúp", "cứu", "chia sẻ", "an ủi", "bảo vệ", "tin tưởng", "xin lỗi"])
				var negative := _has_any(lower, ["đe dọa", "bỏ mặc", "lừa", "đánh", "cướp", "phản đối"])
				if positive:
					change_affinity(npc_index, 5, "Anker đã có hành động hỗ trợ hoặc thể hiện thiện chí.")
					response = "Hành động thiện chí được ghi nhận. Mối quan hệ với %s tiến triển." % npc.name
				elif negative:
					change_affinity(npc_index, -7, "Anker đã có hành động khiến cô ấy tổn thương hoặc mất lòng tin.")
					response = "Hành động này có thể làm %s mất lòng tin. Quan hệ đã thay đổi." % npc.name
				else:
					npc.memory.append("Anker nhắc đến cô ấy vào Ngày %d, %02d:%02d." % [day, hour, minute])
					response = "Cô ấy ghi nhận việc Anker nhắc đến mình, nhưng chưa có hành động cụ thể để thay đổi mối quan hệ."
	if stamina_cost > 0:
		stamina = maxi(0, stamina - stamina_cost)
	_add_story(response)
	add_journal("%s → %s" % [action, _strip_markup(response)])
	gain_experience(2)
	register_dialogue_turn()
	state_changed.emit()

func enter_location(location: String) -> void:
	if not FLOOR_DATA.has(location) or game_over or combat_active:
		return
	current_location = location
	if not discovered_floors.has(location):
		discovered_floors.append(location)
	_add_story("<b>%s</b> — %s" % [FLOOR_DATA[location].title, FLOOR_DATA[location].description])
	var meeting_map := {"Tầng 2":"Thảo Vy", "Tầng 3":"Mai Anh", "Tầng 5":"Ngọc Hân", "Tầng 6":"Hạ Linh"}
	if meeting_map.has(location):
		_meet_main_npc(String(meeting_map[location]), location)
	if location == "Tầng 5":
		_add_story("Một tiếng đập mạnh vang lên sau cánh cửa chống cháy. Có người mắc kẹt bên trong. Khi tiến gần, một bóng người bất ngờ lao ra từ góc khuất!")
		start_combat("Zombie cư dân", 65, 12, 90)
	elif rng.randf() < 0.28:
		start_combat("Zombie lang thang", 40, 8, 70)
	else:
		_add_story("Khu vực tạm thời yên ắng. Anh có thể tìm kiếm vật tư hoặc tiếp tục di chuyển.")
	register_dialogue_turn()
	state_changed.emit()

func _meet_main_npc(npc_name: String, location: String) -> void:
	for npc in npcs:
		if String(npc.name) == npc_name and not bool(npc.get("met", false)):
			npc.met = true
			npc.status = "Đã gặp Anker · " + location
			npc.memory.append("Lần đầu gặp Anker tại " + location + ".")
			_add_story("<b>GẶP GỠ:</b> %s xuất hiện. %s" % [npc_name, _first_meeting_line(npc_name)])
			_check_four_gathering()
			return

func _check_four_gathering() -> void:
	if group_bond_scene_seen:
		return
	for npc in npcs:
		if not bool(npc.get("met", false)):
			return
	group_bond_scene_seen = true
	_add_story("<b>NHỮNG MỐI LIÊN KẾT CŨ:</b> Mai Anh và Thảo Vy nhận ra nhau từ nhóm thiện nguyện từng hỗ trợ sơ tán cư dân. Hạ Linh và Ngọc Hân từng phối hợp trong ban an toàn chung cư. Cả bốn đã gặp nhau trong buổi diễn tập phòng cháy vài tháng trước; giờ những mối quen biết rời rạc ấy trở thành sợi dây níu họ lại giữa thảm họa.")

func _first_meeting_line(npc_name: String) -> String:
	match npc_name:
		"Mai Anh": return "Cô đang giữ một túi cứu thương và cố trấn an vài cư dân bị thương. Cô quan sát Anker đầy cảnh giác."
		"Thảo Vy": return "Cô vừa chặn một cánh cửa bằng tủ gỗ. Mồ hôi lấm tấm trên trán, nhưng ánh mắt vẫn rất tỉnh táo."
		"Hạ Linh": return "Cô đang nối lại dây camera an ninh bằng một bộ dụng cụ tự chế. Cô không rời mắt khỏi màn hình."
		_: return "Cô đứng chắn trước cầu thang thoát hiểm, tay cầm một thanh kim loại và không cho ai tiến lại gần."

func search_current_floor() -> String:
	if game_over or combat_active:
		return "Không thể tìm kiếm khi đang giao chiến hoặc đã Game Over."
	if searched_floors.has(current_location):
		return "Khu vực này đã được tìm kiếm. Không còn vật tư dễ thấy."
	searched_floors.append(current_location)
	stamina = maxi(0, stamina - 8)
	var loot: Array = FLOOR_DATA[current_location].loot
	var found_name: String = loot[rng.randi_range(0, loot.size() - 1)]
	var quantity := 1
	if found_name.begins_with("Đạn"):
		var weapon_name := found_name.replace("Đạn ", "")
		var ammo_key := weapon_name.to_lower()
		if ammo_key == "súng lục": ammo_key = "Súng lục"
		if ammo_key == "shotgun": ammo_key = "Shotgun"
		if ammo_key == "súng tỉa": ammo_key = "Súng tỉa"
		_add_ammo(ammo_key, 2)
		return "Tìm thấy 2 viên đạn cho %s." % ammo_key
	if WEAPON_DATA.has(found_name):
		add_weapon(found_name)
		return "Tìm thấy vũ khí: %s." % found_name
	_add_item(found_name, quantity)
	return "Tìm thấy: %s ×%d." % [found_name, quantity]

func _add_item(item_name: String, quantity: int = 1) -> void:
	for item in inventory:
		if item.name == item_name:
			item.quantity = int(item.quantity) + quantity
			return
	inventory.append({"name":item_name, "quantity":quantity, "type":"supply"})

func _add_ammo(weapon_name: String, amount: int) -> void:
	for item in inventory:
		if item.name == weapon_name and String(item.get("type", "")) == "weapon":
			item.ammo = int(item.get("ammo", 0)) + amount
			return
	_add_item("Đạn " + weapon_name, amount)

func add_weapon(weapon_name: String, ammo: int = -1) -> void:
	if not WEAPON_DATA.has(weapon_name) or weapon_name == "Tay không":
		return
	for item in inventory:
		if item.name == weapon_name:
			if String(item.get("type", "")) == "weapon":
				item.ammo = int(item.get("ammo", 0)) + maxi(0, ammo)
				return
	var data: Dictionary = WEAPON_DATA[weapon_name]
	var starting_ammo := ammo if ammo >= 0 else int(data.ammo)
	var ammo_item_name := "Đạn " + weapon_name
	for i in range(inventory.size()):
		if inventory[i].name == ammo_item_name:
			starting_ammo += int(inventory[i].quantity)
			inventory.remove_at(i)
			break
	inventory.append({"name":weapon_name, "quantity":1, "type":"weapon", "damage":data.damage, "noise":data.noise, "ammo":starting_ammo})

func available_weapons() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	result.append({"name":"Tay không", "damage":WEAPON_DATA["Tay không"].damage, "noise":0, "ammo":-1, "description":WEAPON_DATA["Tay không"].description})
	for item in inventory:
		if String(item.get("type", "")) == "weapon":
			var ammo := int(item.get("ammo", -1))
			if ammo != 0:
				result.append({"name":item.name, "damage":int(item.get("damage", 5)), "noise":int(item.get("noise", 0)), "ammo":ammo, "description":WEAPON_DATA.get(item.name, {}).get("description", "")})
	return result

func start_combat(name: String, hp: int, damage: int, noise: int) -> void:
	if combat_active or game_over:
		return
	combat_active = true
	zombie_name = name
	zombie_health = hp
	zombie_max_health = hp
	zombie_damage = damage
	zombie_noise_level = noise
	zombie_turn = 0
	_add_story("<b>GIAO CHIẾN:</b> %s xuất hiện! Chọn vũ khí hoặc tay không. Zombie sẽ phản công theo lượt." % zombie_name)
	combat_changed.emit()
	state_changed.emit()

func use_weapon(weapon_name: String) -> void:
	if not combat_active or game_over:
		return
	var weapon: Dictionary = {}
	for item in available_weapons():
		if item.name == weapon_name:
			weapon = item
			break
	if weapon.is_empty():
		return
	if int(weapon.ammo) == 0:
		_add_story("Không còn đạn cho %s." % weapon_name)
		return
	var damage := int(weapon.damage)
	zombie_health = maxi(0, zombie_health - damage)
	_add_story("%s gây %d sát thương lên %s bằng %s. Zombie còn %d/%d HP." % [player_name, damage, zombie_name, weapon_name, zombie_health, zombie_max_health])
	if int(weapon.ammo) > 0:
		for item in inventory:
			if item.name == weapon_name and String(item.get("type", "")) == "weapon":
				item.ammo = maxi(0, int(item.ammo) - 1)
				break
	var noise := int(weapon.noise)
	if noise >= 70:
		_add_story("<b>TIẾNG SÚNG!</b> Âm thanh vang dội khắp chung cư. Những tiếng gầm đáp lại từ nhiều tầng.")
		if not noise_investigated:
			_add_story("<b>BAD END — ĐÀN XÁC SỐNG:</b> Vì đã bỏ qua việc tìm hiểu tiếng ồn, Anker không lường được hậu quả. Tiếng súng kéo một đàn zombie áp đảo tới khu vực. Không còn đường thoát.")
			game_over = true
			combat_active = false
			combat_changed.emit()
			state_changed.emit()
			return
		else:
			_add_story("Nhờ đã điều tra trước đó, Anker hiểu tiếng súng sẽ kéo zombie tới. Cần kết thúc giao tranh và rời khỏi đây thật nhanh.")
			zombie_damage += 4
			if rng.randf() < 0.35:
				_add_story("Một zombie khác bị tiếng súng thu hút và xuất hiện ở cuối hành lang!")
				zombie_health += 25
				zombie_max_health += 25
				zombie_damage += 3
	if zombie_health <= 0:
		combat_active = false
		_add_story("<b>CHIẾN THẮNG:</b> %s đã bị hạ. Khu vực tạm thời an toàn." % zombie_name)
		gain_experience(20)
		combat_changed.emit()
		state_changed.emit()
		return
	_zombie_attack()
	register_dialogue_turn()
	combat_changed.emit()
	state_changed.emit()

func _zombie_attack() -> void:
	if not combat_active or game_over:
		return
	zombie_turn += 1
	var roll := rng.randf()
	if roll < 0.12:
		_add_story("<b>LƯỢT ZOMBIE %d:</b> %s vồ hụt, móng tay cào mạnh vào bức tường ngay cạnh." % [zombie_turn, zombie_name])
		return
	var damage := maxi(1, zombie_damage - int(stamina / 35))
	var attack_label := "đòn tấn công thường"
	if roll > 0.82:
		damage = int(damage * 1.5)
		attack_label = "cú lao tới dữ dội"
	health = maxi(0, health - damage)
	stamina = maxi(0, stamina - 4)
	_add_story("<b>LƯỢT ZOMBIE %d:</b> %s tung %s, gây %d sát thương. HP của %s còn %d." % [zombie_turn, zombie_name, attack_label, damage, player_name, health])
	if health <= 0:
		game_over = true
		combat_active = false
		_add_story("<b>GAME OVER</b> — %s đã bị zombie hạ gục." % player_name)

func attempt_escape() -> void:
	if not combat_active or game_over:
		return
	if rng.randf() < 0.55:
		combat_active = false
		_add_story("Anker thoát khỏi giao tranh và lùi về khu vực an toàn.")
	else:
		_add_story("Đường rút bị chặn! Zombie chớp lấy cơ hội tấn công.")
		_zombie_attack()
	register_dialogue_turn()
	combat_changed.emit()
	state_changed.emit()

func change_affinity(npc_index: int, amount: int, memory_text: String) -> void:
	if npc_index < 0 or npc_index >= npcs.size():
		return
	var npc: Dictionary = npcs[npc_index]
	npc.affinity = clampi(int(npc.affinity) + amount, -100, 100)
	npc.memory.append(memory_text)
	_check_special_ending()
	state_changed.emit()

func _check_special_ending() -> void:
	special_ending_unlocked = true
	for npc in npcs:
		if int(npc.affinity) < 100:
			special_ending_unlocked = false
			return

func get_affinity_label(value: int) -> String:
	if value < 0: return "Đối địch"
	if value <= 25: return "Người lạ"
	if value <= 50: return "Người quen"
	if value <= 75: return "Tin tưởng"
	return "Thân thuộc"

func get_special_ending() -> void:
	if not special_ending_unlocked:
		return
	special_ending_seen = true
	_add_story("<b>KẾT THÚC ĐẶC BIỆT — MỘT MÁI NHÀ:</b> Sau tất cả mất mát, Anker, Mai Anh, Thảo Vy, Hạ Linh và Ngọc Hân chọn ở lại bên nhau. Họ cùng xây dựng một mái nhà mới giữa thế giới đổ nát.")
	game_over = true
	state_changed.emit()

func _find_npc_in_text(value: String) -> int:
	for i in range(npcs.size()):
		if value.contains(String(npcs[i].name).to_lower()):
			return i
	return -1

func _consume_item(item_name: String) -> bool:
	for i in range(inventory.size()):
		if inventory[i].name == item_name and int(inventory[i].quantity) > 0:
			inventory[i].quantity -= 1
			if inventory[i].quantity <= 0:
				inventory.remove_at(i)
			return true
	return false

func gain_experience(amount: int) -> void:
	experience += amount
	var threshold := level * 100
	while experience >= threshold:
		experience -= threshold
		level += 1
		threshold = level * 100
		_add_story("<b>LEVEL UP!</b> %s đạt cấp %d." % [player_name, level])

func save_game() -> bool:
	var data := {
		"player_name":player_name,"started":started,"day":day,"hour":hour,"minute":minute,
		"health":health,"stamina":stamina,"hunger":hunger,"thirst":thirst,"level":level,
		"experience":experience,"game_over":game_over,"special_ending_unlocked":special_ending_unlocked,
		"special_ending_seen":special_ending_seen,"current_location":current_location,"inventory":inventory,
		"journal":journal,"story":story,"minutes_since_survival_tick":minutes_since_survival_tick,
		"dialogue_turns":dialogue_turns,"npcs":npcs,"side_npcs":side_npcs,"discovered_floors":discovered_floors,
		"searched_floors":searched_floors,"noise_investigated":noise_investigated,
		"noise_warning_ignored":noise_warning_ignored,"bad_end_route":bad_end_route,
		"rescued_visitor_count":rescued_visitor_count,"negative_relationship_events":negative_relationship_events,
		"group_bond_scene_seen":group_bond_scene_seen
	}
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null: return false
	file.store_string(JSON.stringify(data))
	file.close()
	return true

func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH): return false
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null: return false
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_DICTIONARY: return false
	var scalar_keys := ["player_name","started","day","hour","minute","health","stamina","hunger","thirst","level","experience","game_over","special_ending_unlocked","special_ending_seen","current_location","minutes_since_survival_tick","dialogue_turns","noise_investigated","noise_warning_ignored","bad_end_route","rescued_visitor_count","negative_relationship_events","group_bond_scene_seen"]
	for key in scalar_keys:
		if parsed.has(key): set(key, parsed[key])
	inventory.clear()
	for item in parsed.get("inventory", []): inventory.append(item)
	journal.clear()
	for line in parsed.get("journal", []): journal.append(String(line))
	story.clear()
	for line in parsed.get("story", []): story.append(String(line))
	npcs.clear()
	for npc in parsed.get("npcs", []): npcs.append(npc)
	side_npcs.clear()
	for npc in parsed.get("side_npcs", []): side_npcs.append(npc)
	discovered_floors.clear()
	for floor_name in parsed.get("discovered_floors", ["Tầng trệt"]): discovered_floors.append(String(floor_name))
	searched_floors.clear()
	for floor_name in parsed.get("searched_floors", []): searched_floors.append(String(floor_name))
	_check_special_ending()
	combat_active = false
	pending_visitor.clear()
	state_changed.emit()
	return true

func _has_any(value: String, words: Array) -> bool:
	for word in words:
		if value.contains(String(word)): return true
	return false

func _escape_bbcode(value: String) -> String:
	return value.replace("[", "(").replace("]", ")")

func _strip_markup(value: String) -> String:
	return value.replace("<b>", "").replace("</b>", "")
