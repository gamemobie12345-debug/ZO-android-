extends Control

const StateScript = preload("res://scripts/game_state.gd")
var state: GameState
var root_box: VBoxContainer
var content_scroll: ScrollContainer
var content_box: VBoxContainer
var action_input: LineEdit
var story_view: RichTextLabel
var stats_labels := {}
var npc_box: VBoxContainer
var inventory_label: Label
var journal_label: Label
var intro_name: LineEdit
var status_label: Label
var location_label: Label
var noise_panel: VBoxContainer
var visitor_panel: VBoxContainer
var combat_popup: PopupPanel
var combat_box: VBoxContainer
var combat_title: Label
var combat_health: ProgressBar
var combat_info: Label
var special_button: Button

const BG := Color("0b1119")
const PANEL := Color("151f2b")
const PANEL_2 := Color("1c2937")
const TEXT := Color("e8edf2")
const MUTED := Color("91a0ae")
const ACCENT := Color("d5a45d")
const RED := Color("d66a66")
const GREEN := Color("78b98b")

func _ready() -> void:
	state = StateScript.new()
	add_child(state)
	state.state_changed.connect(_refresh)
	_build_shell()
	if state.load_game():
		_build_game_screen()
	else:
		_build_intro()

func _build_shell() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	root_box = VBoxContainer.new()
	root_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root_box.add_theme_constant_override("separation", 0)
	add_child(root_box)

func _build_intro() -> void:
	_clear_root()
	var center := CenterContainer.new()
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root_box.add_child(center)
	var panel := _panel()
	panel.custom_minimum_size = Vector2(340, 0)
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	panel.add_child(box)
	var eyebrow := _label("OFFLINE SURVIVAL RPG  ·  ANDROID", 11, ACCENT)
	eyebrow.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(eyebrow)
	var title := _label("ZOMBIE\nOUTBREAK", 34, TEXT, true)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)
	var subtitle := _label("Một thế giới không chờ đợi ai.", 14, MUTED)
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(subtitle)
	box.add_child(HSeparator.new())
	box.add_child(_label("Tên người sống sót", 13, MUTED))
	intro_name = LineEdit.new()
	intro_name.text = "Anker"
	intro_name.placeholder_text = "Nhập tên nhân vật"
	intro_name.custom_minimum_size.y = 48
	_style_input(intro_name)
	box.add_child(intro_name)
	var start := _button("BẮT ĐẦU SINH TỒN", ACCENT)
	start.pressed.connect(func():
		state.start_game(intro_name.text)
		_build_game_screen()
	)
	box.add_child(start)
	var note := _label("Ngày 1 · 07:42 · Chung cư tại Sài Gòn\nTiến trình được lưu trên thiết bị. Không cần Internet.", 11, MUTED)
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(note)

func _build_game_screen() -> void:
	_clear_root()
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 8)
	header.add_theme_constant_override("margin_left", 14)
	header.add_theme_constant_override("margin_right", 14)
	header.add_theme_constant_override("margin_top", 10)
	header.add_theme_constant_override("margin_bottom", 10)
	root_box.add_child(header)
	var brand := VBoxContainer.new()
	brand.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(brand)
	brand.add_child(_label("ZOMBIE OUTBREAK", 16, ACCENT, true))
	brand.add_child(_label("ANDROID EDITION  ·  OFFLINE", 9, MUTED))
	var save_btn := _small_button("LƯU")
	save_btn.pressed.connect(func(): _show_status("Đã lưu tiến trình." if state.save_game() else "Không thể lưu tiến trình."))
	header.add_child(save_btn)
	var load_btn := _small_button("TẢI")
	load_btn.pressed.connect(func(): _show_status("Đã tải tiến trình." if state.load_game() else "Chưa có bản lưu."))
	header.add_child(load_btn)
	root_box.add_child(HSeparator.new())
	content_scroll = ScrollContainer.new()
	content_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root_box.add_child(content_scroll)
	content_box = VBoxContainer.new()
	content_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content_box.add_theme_constant_override("separation", 10)
	content_box.add_theme_constant_override("margin_left", 12)
	content_box.add_theme_constant_override("margin_right", 12)
	content_box.add_theme_constant_override("margin_top", 10)
	content_box.add_theme_constant_override("margin_bottom", 12)
	content_scroll.add_child(content_box)
	_build_dashboard()
	_build_noise_choice()
	_build_map()
	_build_visitor_panel()
	_build_npcs()
	_build_inventory()
	_build_story()
	_build_journal()
	var action_card := _panel()
	content_box.add_child(action_card)
	var action_col := VBoxContainer.new()
	action_col.add_theme_constant_override("separation", 7)
	action_card.add_child(action_col)
	action_col.add_child(_label("HÀNH ĐỘNG", 12, ACCENT, true))
	var action_row := HBoxContainer.new()
	action_col.add_child(action_row)
	action_input = LineEdit.new()
	action_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	action_input.placeholder_text = "Nhập hành động của anh..."
	action_input.custom_minimum_size.y = 44
	_style_input(action_input)
	action_input.text_submitted.connect(_submit_action)
	action_row.add_child(action_input)
	var send := _button("GỬI", ACCENT)
	send.custom_minimum_size.x = 68
	send.pressed.connect(func(): _submit_action(action_input.text))
	action_row.add_child(send)
	var quick_row := HBoxContainer.new()
	quick_row.add_theme_constant_override("separation", 6)
	action_col.add_child(quick_row)
	var search_btn := _small_button("TÌM VẬT TƯ")
	search_btn.pressed.connect(func(): _show_action_result(state.search_current_floor()))
	quick_row.add_child(search_btn)
	var rest_btn := _small_button("NGHỈ 10 PHÚT")
	rest_btn.pressed.connect(func():
		state.stamina = mini(100, state.stamina + 12)
		state.advance_time(10)
		state.register_dialogue_turn()
		state._add_story("Anker nghỉ ngơi, thể lực hồi phục một phần.")
		state.state_changed.emit()
	)
	quick_row.add_child(rest_btn)
	special_button = _button("MỞ KẾT THÚC ĐẶC BIỆT", GREEN)
	special_button.pressed.connect(func(): state.get_special_ending())
	action_col.add_child(special_button)
	status_label = _label("", 10, GREEN)
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root_box.add_child(status_label)
	_build_combat_popup()
	_refresh()
	_refresh_combat()
	_refresh_visitor()

func _build_dashboard() -> void:
	var card := _panel()
	content_box.add_child(card)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 8)
	card.add_child(col)
	var top := HBoxContainer.new()
	col.add_child(top)
	var who := VBoxContainer.new()
	who.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(who)
	who.add_child(_label("NGƯỜI SỐNG SÓT", 10, MUTED))
	who.add_child(_label(state.player_name.to_upper(), 22, TEXT, true))
	var time := VBoxContainer.new()
	time.alignment = BoxContainer.ALIGNMENT_END
	top.add_child(time)
	stats_labels["clock"] = _label("NGÀY 1 · 07:42", 13, ACCENT, true)
	time.add_child(stats_labels["clock"])
	stats_labels["level"] = _label("CẤP 1 · XP 0/100", 10, MUTED)
	time.add_child(stats_labels["level"])
	location_label = _label("VỊ TRÍ: TẦNG TRỆT", 10, ACCENT, true)
	col.add_child(location_label)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	col.add_child(grid)
	for key in ["health", "stamina", "hunger", "thirst"]:
		var stat_card := PanelContainer.new()
		_style_panel(stat_card, PANEL_2)
		grid.add_child(stat_card)
		var stat_col := VBoxContainer.new()
		stat_col.add_theme_constant_override("separation", 4)
		stat_card.add_child(stat_col)
		stats_labels[key + "_name"] = _label(key.to_upper(), 9, MUTED)
		stat_col.add_child(stats_labels[key + "_name"])
		stats_labels[key] = _label("100 / 100", 17, TEXT, true)
		stat_col.add_child(stats_labels[key])
		var bar := ProgressBar.new()
		bar.custom_minimum_size.y = 7
		bar.show_percentage = false
		bar.max_value = 100
		stats_labels[key + "_bar"] = bar
		stat_col.add_child(bar)
	col.add_child(_label("Mỗi 3 lượt thoại: thời gian trôi 2 phút. Đói/khát giảm 5 mỗi 60 phút; khi một chỉ số về 0, HP mất 5 mỗi giờ.", 10, MUTED))

func _build_noise_choice() -> void:
	var card := _panel()
	content_box.add_child(card)
	noise_panel = VBoxContainer.new()
	noise_panel.add_theme_constant_override("separation", 7)
	card.add_child(noise_panel)
	noise_panel.add_child(_label("CẢNH BÁO ÂM THANH", 12, ACCENT, true))
	noise_panel.add_child(_label("Có nên tìm hiểu xem zombie có nhạy cảm với tiếng ồn không? Bỏ qua dấu hiệu này có thể dẫn đến một kết cục thảm khốc.", 11, TEXT))
	var row := HBoxContainer.new()
	noise_panel.add_child(row)
	var investigate := _button("TÌM HIỂU", GREEN)
	investigate.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	investigate.pressed.connect(func(): state.investigate_noise())
	row.add_child(investigate)
	var ignore := _button("BỎ QUA", RED)
	ignore.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ignore.pressed.connect(func(): state.ignore_noise_warning())
	row.add_child(ignore)

func _build_map() -> void:
	var card := _panel()
	content_box.add_child(card)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 7)
	card.add_child(col)
	col.add_child(_label("BẢN ĐỒ CHUNG CƯ", 12, ACCENT, true))
	col.add_child(_label("8 khu vực chính + 1 tầng hầm. Tầng 5 đang có người mắc kẹt.", 10, MUTED))
	var rows := ["Tầng hầm", "Tầng trệt", "Tầng 2", "Tầng 3", "Tầng 4", "Tầng 5", "Tầng 6", "Tầng 7", "Sân thượng"]
	for location in rows:
		var btn := _small_button(location.to_upper())
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		btn.pressed.connect(state.enter_location.bind(location))
		col.add_child(btn)

func _build_visitor_panel() -> void:
	var card := _panel()
	content_box.add_child(card)
	visitor_panel = VBoxContainer.new()
	visitor_panel.add_theme_constant_override("separation", 7)
	card.add_child(visitor_panel)
	visitor_panel.add_child(_label("NGƯỜI LẠ Ở CỬA", 12, ACCENT, true))
	visitor_panel.add_child(_label("Chưa có ai xuất hiện.", 10, MUTED))

func _build_npcs() -> void:
	var card := _panel()
	content_box.add_child(card)
	npc_box = VBoxContainer.new()
	npc_box.add_theme_constant_override("separation", 8)
	card.add_child(npc_box)
	npc_box.add_child(_label("BỐN NHÂN VẬT CHÍNH", 12, ACCENT, true))

func _build_inventory() -> void:
	var card := _panel()
	content_box.add_child(card)
	var col := VBoxContainer.new()
	card.add_child(col)
	col.add_child(_label("TÚI ĐỒ", 12, ACCENT, true))
	inventory_label = _label("Trống", 12, MUTED)
	col.add_child(inventory_label)

func _build_story() -> void:
	var card := _panel()
	content_box.add_child(card)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 7)
	card.add_child(col)
	col.add_child(_label("DIỄN BIẾN", 12, ACCENT, true))
	story_view = RichTextLabel.new()
	story_view.bbcode_enabled = true
	story_view.fit_content = true
	story_view.scroll_active = false
	story_view.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	story_view.add_theme_color_override("default_color", TEXT)
	story_view.add_theme_font_size_override("normal_font_size", 13)
	story_view.add_theme_constant_override("line_separation", 5)
	col.add_child(story_view)

func _build_journal() -> void:
	var card := _panel()
	content_box.add_child(card)
	var col := VBoxContainer.new()
	card.add_child(col)
	col.add_child(_label("NHẬT KÝ", 12, ACCENT, true))
	journal_label = _label("Chưa có ghi chép.", 11, MUTED)
	journal_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(journal_label)

func _build_combat_popup() -> void:
	combat_popup = PopupPanel.new()
	combat_popup.size = Vector2i(420, 640)
	add_child(combat_popup)
	combat_box = VBoxContainer.new()
	combat_box.add_theme_constant_override("separation", 8)
	combat_box.add_theme_constant_override("margin_left", 14)
	combat_box.add_theme_constant_override("margin_right", 14)
	combat_box.add_theme_constant_override("margin_top", 14)
	combat_box.add_theme_constant_override("margin_bottom", 14)
	combat_popup.add_child(combat_box)

func _refresh_combat() -> void:
	if combat_popup == null:
		return
	for child in combat_box.get_children():
		child.queue_free()
	if not state.combat_active:
		if combat_popup.visible:
			combat_popup.hide()
		return
	combat_title = _label("ZOMBIE ĐANG TẤN CÔNG", 17, RED, true)
	combat_box.add_child(combat_title)
	combat_box.add_child(_label("%s · Lượt %d" % [state.zombie_name, state.zombie_turn + 1], 12, TEXT))
	combat_health = ProgressBar.new()
	combat_health.max_value = state.zombie_max_health
	combat_health.value = state.zombie_health
	combat_health.custom_minimum_size.y = 14
	combat_box.add_child(combat_health)
	combat_info = _label("Zombie: %d/%d HP\nChọn vũ khí trong túi hoặc chiến đấu bằng tay không. Sau đòn đánh, zombie sẽ phản công.", 11, MUTED)
	combat_box.add_child(combat_info)
	combat_box.add_child(_label("CHỌN VŨ KHÍ", 12, ACCENT, true))
	for weapon in state.available_weapons():
		var ammo_text := "∞" if int(weapon.ammo) < 0 else "Đạn: %d" % int(weapon.ammo)
		var button := _small_button("%s  ·  %d sát thương  ·  %s" % [weapon.name, weapon.damage, ammo_text])
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.pressed.connect(state.use_weapon.bind(String(weapon.name)))
		combat_box.add_child(button)
	var escape := _button("BỎ CHẠY", RED)
	escape.pressed.connect(func(): state.attempt_escape())
	combat_box.add_child(escape)
	if not combat_popup.visible:
		combat_popup.popup_centered(Vector2i(420, 640))

func _refresh_visitor() -> void:
	if visitor_panel == null:
		return
	for child in visitor_panel.get_children():
		child.queue_free()
	visitor_panel.add_child(_label("NGƯỜI LẠ Ở CỬA", 12, ACCENT, true))
	if state.pending_visitor.is_empty():
		visitor_panel.add_child(_label("Chưa có ai xuất hiện.", 10, MUTED))
		return
	var visitor_name: String = state.pending_visitor.name
	visitor_panel.add_child(_label("%s đang %s và xin được vào nơi trú ẩn. Anh sẽ xử lý thế nào?" % [visitor_name, state.pending_visitor.condition], 11, TEXT))
	var row := HBoxContainer.new()
	visitor_panel.add_child(row)
	var rescue := _small_button("CỨU GIÚP")
	rescue.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rescue.pressed.connect(state.resolve_visitor.bind("rescue"))
	row.add_child(rescue)
	var ignore := _small_button("TỪ CHỐI")
	ignore.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ignore.pressed.connect(state.resolve_visitor.bind("ignore"))
	row.add_child(ignore)


func _refresh() -> void:
	if content_box == null or not is_instance_valid(content_box) or not state.started:
		return
	if stats_labels.has("clock"):
		stats_labels.clock.text = "NGÀY %d · %02d:%02d" % [state.day, state.hour, state.minute]
		stats_labels.level.text = "CẤP %d · XP %d/%d" % [state.level, state.experience, state.level * 100]
		location_label.text = "VỊ TRÍ: %s" % state.current_location.to_upper()
		_set_stat("health", state.health)
		_set_stat("stamina", state.stamina)
		_set_stat("hunger", state.hunger)
		_set_stat("thirst", state.thirst)
	if noise_panel:
		noise_panel.visible = not state.noise_investigated and not state.noise_warning_ignored
	if npc_box:
		for child in npc_box.get_children():
			if child != npc_box.get_child(0): child.queue_free()
		for npc in state.npcs:
			var row := HBoxContainer.new()
			row.add_theme_constant_override("separation", 8)
			npc_box.add_child(row)
			var details := VBoxContainer.new()
			details.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			row.add_child(details)
			details.add_child(_label("%s · %d tuổi" % [npc.name, npc.age], 13, TEXT, true))
			details.add_child(_label("%s  |  %s" % [npc.job, npc.specialty], 10, MUTED))
			details.add_child(_label(String(npc.status), 9, MUTED))
			details.add_child(_label("Liên kết: " + String(npc.bond), 9, MUTED))
			var relation := VBoxContainer.new()
			relation.alignment = BoxContainer.ALIGNMENT_CENTER
			row.add_child(relation)
			relation.add_child(_label("LV.%d" % npc.level, 10, ACCENT, true))
			var affinity := int(npc.affinity)
			var affinity_color := GREEN if affinity >= 0 else RED
			relation.add_child(_label("%+d" % affinity, 12, affinity_color, true))
			relation.add_child(_label(state.get_affinity_label(affinity), 9, affinity_color))
	if story_view:
		var combined := ""
		for entry in state.story:
			combined += "[color=#91a0ae]────────────────────[/color]\n" + entry + "\n\n"
		story_view.text = combined
	if inventory_label:
		if state.inventory.is_empty():
			inventory_label.text = "Trống"
		else:
			var items: Array[String] = []
			for item in state.inventory:
				var extra := ""
				if String(item.get("type", "")) == "weapon": extra = " · Đạn %d" % int(item.get("ammo", -1))
				items.append("%s ×%d%s" % [item.name, item.quantity, extra])
			inventory_label.text = PackedStringArray(items).join("  ·  ")
	if journal_label:
		journal_label.text = PackedStringArray(state.journal.slice(0, 8)).join("\n") if not state.journal.is_empty() else "Chưa có ghi chép."
	if special_button:
		special_button.visible = state.special_ending_unlocked and not state.special_ending_seen
	if state.game_over:
		_show_status("GAME OVER · Tiến trình vẫn có thể được lưu.")
	_refresh_combat()
	_refresh_visitor()

func _set_stat(key: String, value: int) -> void:
	if stats_labels.has(key):
		stats_labels[key].text = "%d / 100" % value
		stats_labels[key + "_bar"].value = value
		stats_labels[key].add_theme_color_override("font_color", RED if value <= 25 else TEXT)

func _submit_action(value: String) -> void:
	if value.strip_edges().is_empty(): return
	state.perform_action(value)
	action_input.clear()
	if content_scroll:
		await get_tree().process_frame
		content_scroll.scroll_vertical = 0

func _show_action_result(message: String) -> void:
	if state.game_over or state.combat_active:
		return
	state._add_story(message)
	state.add_journal(message)
	state.register_dialogue_turn()
	state.state_changed.emit()

func _show_status(message: String) -> void:
	if status_label: status_label.text = message

func _clear_root() -> void:
	for child in root_box.get_children(): child.queue_free()
	stats_labels.clear()
	content_box = null
	combat_popup = null
	visitor_panel = null
	noise_panel = null

func _panel() -> PanelContainer:
	var panel := PanelContainer.new()
	_style_panel(panel, PANEL)
	return panel

func _style_panel(panel: PanelContainer, color: Color) -> void:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(12)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 11
	style.content_margin_bottom = 11
	panel.add_theme_stylebox_override("panel", style)

func _label(value: String, size: int, color: Color, bold := false) -> Label:
	var label := Label.new()
	label.text = value
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	if bold: label.add_theme_color_override("font_shadow_color", Color(0,0,0,0.2))
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return label

func _button(value: String, color: Color) -> Button:
	var button := Button.new()
	button.text = value
	button.custom_minimum_size.y = 46
	var normal := StyleBoxFlat.new()
	normal.bg_color = color
	normal.set_corner_radius_all(9)
	button.add_theme_stylebox_override("normal", normal)
	var hover := normal.duplicate()
	hover.bg_color = color.lightened(0.08)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_color_override("font_color", Color("111820"))
	button.add_theme_font_size_override("font_size", 11)
	return button

func _small_button(value: String) -> Button:
	var button := _button(value, PANEL_2)
	button.custom_minimum_size = Vector2(48, 38)
	button.add_theme_color_override("font_color", TEXT)
	button.add_theme_font_size_override("font_size", 9)
	return button

func _style_input(input: LineEdit) -> void:
	input.add_theme_color_override("font_color", TEXT)
	input.add_theme_color_override("font_placeholder_color", MUTED)
	input.add_theme_font_size_override("font_size", 13)
	var style := StyleBoxFlat.new()
	style.bg_color = Color("0e1721")
	style.set_corner_radius_all(8)
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	input.add_theme_stylebox_override("normal", style)
	input.add_theme_stylebox_override("focus", style)
