# Zombie Outbreak — Story Bible (working draft)

## Core premise

The outbreak begins in a Saigon apartment complex on an ordinary morning. The infected are not supernatural omniscient hunters: the fictional pathogen severely disrupts impulse control and amplifies their response to sharp, sudden sound. They can lose track of a quiet target, but gunfire, alarms, breaking glass, and metal impacts can pull them across floors. The building becomes a closed survival ecosystem where every choice consumes time, energy, trust, or supplies.

The player is Anker. The game never writes Anker's speech, thoughts, feelings, or decisions. The world describes what Anker can observe and lets the player choose what happens next.

## Main cast

- **Mai Anh — medical student:** calm, responsible, and strongly motivated to keep injured residents alive. She and Thảo Vy previously volunteered in a neighborhood evacuation group. Her conflict is the boundary between compassion and finite medical supplies.
- **Thảo Vy — office worker:** athletic, direct, energetic, and sometimes impulsive. She trusts action more than discussion and has an old friendship with Mai Anh. Her conflict is learning when courage becomes recklessness.
- **Hạ Linh — IT worker:** quiet, observant, and practical. She once helped Ngọc Hân with the apartment building's safety and camera systems. Her conflict is deciding whether information should be shared when it can make someone a target.
- **Ngọc Hân — resident:** cautious and protective, with strong knowledge of the building. She has worked with Hạ Linh and tends to distrust improvised plans. Her conflict is choosing between protecting a small inner circle and helping strangers.

The four are not interchangeable companions. Their old connections create alliances, disagreements, and private conversations even when Anker is not present.

## Building map

- **Basement:** parking, generator room, maintenance storage. Useful tools, poor visibility, echoing sound.
- **Ground floor:** lobby, security desk, street-facing glass doors. The main entry bottleneck.
- **Floor 2:** family apartments and Thảo Vy's first appearance.
- **Floor 3:** restaurant, kitchen stores, packaged food and water; Mai Anh is helping injured residents nearby.
- **Floor 4:** serviced apartments, medical supplies, signs of forced entry.
- **Floor 5:** blocked fire door and trapped residents; Ngọc Hân is guarding the stairwell. This is an early major danger point.
- **Floor 6:** renovation area and camera/electrical access; Hạ Linh is trying to restore surveillance.
- **Floor 7:** upper apartments and traces of a failed survivor group.
- **Rooftop:** water tanks, antenna, and a possible route to the neighboring roof. It can become an escape route or a last stand.

## Campaign arcs

### Arc I — The First Morning

Emergency messages contradict one another. The player notices that infected people turn toward sudden noise. The early investigation is a meaningful survival decision: skipping it makes the first firearm discharge catastrophically dangerous and commits the story to the horde bad end.

### Arc II — The Fifth Floor

A blocked stairwell traps residents. The player can fight, search for another route, or spend scarce time helping. The four main women are encountered on separate floors, each with a reason to be guarded. Their first impressions should be earned through actions, not automatic friendship.

### Arc III — The Building's Resources

The restaurant, water tanks, maintenance room, and medical supplies become strategic locations. Searching consumes stamina and time. Noise can turn a successful supply run into a siege. The group begins to disagree about who deserves scarce resources.

### Arc IV — People at the Door

Secondary survivors arrive with incomplete stories. Some genuinely need help; some are desperate; a few exploit the group's kindness. Rescuing, refusing, or being robbed should create lasting consequences and memories. Secondary characters remain supporting cast rather than displacing the four leads.

### Arc V — The Signal Above

The rooftop antenna may reach an emergency channel. The signal is intermittent and attracts attention. The group must decide whether to leave the building, search for other survivors, or make the apartment complex defensible. Character-specific outcomes depend on affinity, shared events, survival resources, and who is still alive.

## Special ending

When all four main characters reach 100 affinity and survive, unlock **A Home Among the Ruins**: Anker and the four women choose to stay together and build a home. This ending is optional and must be earned through the full relationship system.

## Tone and writing rules

- Survival suspense, human drama, mystery, and occasional warmth; avoid nonstop combat.
- No direct copying of named scenes, characters, settings, or plots from existing franchises. Use broad genre conventions as inspiration and write original events.
- NPCs only remember what they witnessed, heard from a credible source, or experienced themselves.
- NPCs can take actions and trigger events without Anker's involvement.
- Betrayal is contextual: fear, scarcity, loyalty, and personality shape the form it takes. A 60% trigger chance for negative-affinity characters does not mean every betrayal is a physical attack.
- Every change to HP, stamina, hunger, thirst, inventory, affinity, or NPC status needs a visible cause.
