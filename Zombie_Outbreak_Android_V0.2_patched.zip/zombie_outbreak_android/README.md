# Zombie Outbreak — Android Edition (V0.2 prototype)

A free, offline, single-player survival story RPG built with Godot 4.x and GDScript. The project targets Android APK first and uses no network calls, paid API, account, or dedicated server.

## Implemented in V0.2

- Android-friendly portrait layout and touch-first controls.
- Player name entry; Anker is the default name.
- Starting point: Saigon apartment building, Day 1 at 07:42.
- Player stats: HP 100, stamina 100, hunger 80, thirst 80, level 1.
- Time rule: every 3 player dialogue/action turns advance in-game time by 2 minutes.
- Survival rule: hunger and thirst each fall by 5 every 60 in-game minutes. When hunger reaches 0, HP falls by 5 each hourly tick; when thirst reaches 0, HP also falls by 5. HP 0 means Game Over.
- Apartment exploration: basement, ground floor, floors 2–8, and rooftop. Floor 3 is a restaurant with food and water; floor 5 is a trapped/blocked zone.
- Turn-based combat. At the start of combat a weapon-selection popup appears, listing only weapons currently in the backpack plus the always-available bare hands option.
- Weapon damage: bare hands 5; folding knife 12; baseball bat 18; pipe 20; machete 28; pistol 35; shotgun 55; sniper rifle 90; grenade launcher 100.
- Firearms create very loud noise. If the player has not investigated zombie sound sensitivity before firing a gun, the game enters the bad-ending route. If investigated, the gunshot still attracts more zombies and increases danger.
- Four main female characters: Mai Anh, Thảo Vy, Hạ Linh, Ngọc Hân. Their relationship tiers are Stranger (0–25), Acquaintance (26–50), Trust (51–75), Close (76–100), and Hostile (below 0). Each negative-affinity NPC has a 60% chance to trigger a negative relationship event on a world simulation cycle; this may be conflict, withdrawal, refusal to cooperate, or another character-appropriate setback, and is not automatically betrayal.
- Main characters have pre-existing links and a shared history. Their affinity and level are independent. The special ending unlocks only when all four reach 100 affinity.
- Side survivors can appear. The player can rescue them or refuse; some visitors may steal supplies if ignored.
- Inventory, journal, story log, local save/load.

## Combat balance (prototype values)

| Weapon | Damage | Noise | Ammo |
|---|---:|---:|---:|
| Bare hands | 5 | 0 | Unlimited |
| Folding knife | 12 | 0 | Unlimited |
| Baseball bat | 18 | 4 | Unlimited |
| Pipe | 20 | 5 | Unlimited |
| Machete | 28 | 2 | Unlimited |
| Pistol | 35 | 75 | 6 |
| Shotgun | 55 | 100 | 2 |
| Sniper rifle | 90 | 85 | 1 |
| Grenade launcher | 100 | 100 | 1 |

These are initial tuning values, not final balance. Zombie HP and damage are encounter-specific and will be adjusted after playtesting.

## Story structure (current design direction)

1. **The First Morning:** emergency broadcasts, strange attacks, and the first sound-sensitivity warning.
2. **The Blocked Stairwell:** the fifth floor becomes a rescue and combat bottleneck.
3. **Four Separate Routes:** meet Mai Anh on floor 3, Thảo Vy on floor 2, Ngọc Hân on floor 5, and Hạ Linh on floor 6. Each has a personal reason to protect or distrust others.
4. **A Building Under Pressure:** food, water, power, medical supplies, visitors, and the risk of betrayal shape the group.
5. **The Roof Signal:** the group must decide whether to escape, seek other survivors, or build a safer refuge. The special ending is a relationship outcome, not an automatic reward.

## Open in Godot

1. Install Godot 4.x.
2. Import this folder by opening `project.godot`.
3. Press F6/F5 to run the project.

## Export Android APK

1. Install Android export templates from Godot's Editor > Manage Export Templates.
2. Install Android SDK / build tools and configure Editor Settings > Export > Android.
3. Add an Android export preset (Project > Export > Add > Android).
4. Set package name (example: `com.anker.zombieoutbreak`) and export a debug APK.

The source project is provided here; it has not yet been compiled into an APK in this environment because Godot and Android build tools are not installed here.

## Current prototype limits

- This is a playable systems prototype, not the final complete campaign.
- Action interpretation is local/rule-based, not a generative AI model.
- NPC relationship gains currently use simple keyword-recognized actions after meeting the character; this needs a richer dialogue and consequence system.
- The story outline is in progress. The full chapter scripts, side missions, character-specific endings, more zombie archetypes, and a polished map are future milestones.
