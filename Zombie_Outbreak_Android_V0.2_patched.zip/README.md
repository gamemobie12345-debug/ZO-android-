# Zombie Outbreak — Android

Godot 4.3 offline single-player survival RPG prototype.

## Build APK

The project source is stored in `Zombie_Outbreak_Android_V0.2.zip`. Pushing to `main` or manually starting **Build Android APK** in the Actions tab runs the Android export workflow.

When the workflow succeeds, open its run, scroll to **Artifacts**, and download `Zombie-Outbreak-Android-V0.2`. The ZIP artifact contains the debug APK.

The workflow uses Godot 4.3 and the `barichello/godot-ci:4.3` image with Android export templates and SDK preconfigured. No paid API, app server, or signing secret is required for this debug build.

## Project

- Version: 0.2.0
- Engine: Godot 4.3
- Target: Android APK (debug)
- Package: `com.anker.zombieoutbreak`
- Runtime: offline, single-player
